//
//  crearUser.swift
//  proyecto
//
//  Created by MacOsX on 12/4/23.
//

import SwiftUI

struct crearUser: View {
    @State private var username = ""
        @State private var password = ""
        @State private var confirmPassword = ""
        var body: some View {
            Image("login")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 100, height: 100)
                            .padding(.bottom, 30)
            Form {
                
                Section(header: Text("Información del Usuario")) {
                    TextField("Nombre de usuario", text: $username)
                        .autocapitalization(.none)
                    
                    TextField("Email", text: $username)
                        .autocapitalization(.none)
                    SecureField("Contraseña", text: $password)
                    SecureField("Confirmar contraseña", text: $confirmPassword)
                }
                Section {
                    Button(action: {
                        // Aquí puedes manejar la lógica para crear el usuario
                        self.createUser()
                    }) {
                        Text("Crear Usuario")
                    }
                }
            }
            .navigationBarTitle("Crear Usuario")
        }
        func createUser() {
            // Aquí puedes implementar la lógica para crear el usuario
            // Puedes validar la información, almacenarla localmente o enviarla a un servidor, según tus necesidades.
            // También puedes mostrar una alerta o realizar otras acciones según tus necesidades.
        }
    }

struct crearUser_Previews: PreviewProvider {
    static var previews: some View {
        crearUser()
    }
}
