//
//  ListadoAlumnos.swift
//  proyecto
//
//  Created by MacOsX on 12/9/23.
//

import SwiftUI

struct ListadoAlumnos: View {
    let items = ["Julissa Mejia", "Elena Velasco", "Carlos Josue", "Erick Ramirez", "Josue Eliezer "]
    var body: some View {
       
        VStack {
            
            List {
                            Section(header: Text("listado de Alumnos ")) {
                                HStack {
                                    Text("Elena Velasco")
                                    Spacer()
                                    Text("6 grado")
                                        .foregroundColor(.gray)
                                }
                                HStack {
                                    Text("Carlos Quintanilla")
                                    Spacer()
                                    Text("1 grado")
                                        .foregroundColor(.gray)
                                }
                                HStack {
                                    Text("Josue Eliezer ")
                                    Spacer()
                                    Text("9 grado")
                                        .foregroundColor(.gray)
                                }
                                HStack {
                                    Text("jose eusebio")
                                    Spacer()
                                    Text("7 grado")
                                        .foregroundColor(.gray)
                                }
                                HStack {
                                    Text("Eustaqui Alberto")
                                    Spacer()
                                    Text("6 grado")
                                        .foregroundColor(.gray)
                                }
                                HStack {
                                    Text("Lorena Pena")
                                    Spacer()
                                    Text("1 grado")
                                        .foregroundColor(.gray)
                                }
                            }

                            

                            

                            
                        }
                        .navigationBarTitle("Alumnos")
           
                .listStyle(InsetGroupedListStyle())
            
            }
    }
}
struct DetailView: View {
    var item: String
    var body: some View {
        Text("detalle de \(item)")
            .navigationBarTitle(item)
    }
}
struct ListadoAlumnos_Previews: PreviewProvider {
    static var previews: some View {
        ListadoAlumnos()
    }
}
