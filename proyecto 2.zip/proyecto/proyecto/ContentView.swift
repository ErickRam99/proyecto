import SwiftUI
 
struct ContentView: View {
    @State private var isActiveScreen1 = false
    @State private var isActiveScreen2 = false
    @State var username: String = ""
            @State var password: String = ""
    var body: some View {
        NavigationView {
            VStack {
                Image("colegio")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 100, height: 100)
                                .padding(.bottom, 30)
                            TextField("Usuario", text: $username)
                                            .keyboardType(.emailAddress)
                                            .disableAutocorrection(true)
                                            .autocapitalization(.none)
                                            .padding(6)
                                            .font(.headline)
                                            .background(Color.gray.opacity(0.3))
                                            .cornerRadius(6)
                                            .padding(.horizontal, 10)
                                            .padding(.top, 5)
                                            .onChange(of: username, perform: { value in
                                                print("Username value \(value)")
                                            })
                SecureField("Password", text: $password)
                                            .keyboardType(.emailAddress)
                                            .disableAutocorrection(true)
                                            .autocapitalization(.none)
                                            .padding(6)
                                            .font(.headline)
                                            .background(Color.gray.opacity(0.3))
                                            .cornerRadius(6)
                                            .padding(.horizontal, 10)
                                            .onChange(of: password, perform: { value in
                                                print("Password value \(value)")
                                            })
                Button("Iniciar Session") {
                    isActiveScreen1 = true
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
                .padding()
 
                Button("Registrarse") {
                    isActiveScreen2 = true
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
                .padding()
                NavigationLink(
                    destination: menu(),
                    isActive: $isActiveScreen1,
                    label: { EmptyView() }
                )
 
                NavigationLink(
                    destination: crearUser(),
                    isActive: $isActiveScreen2,
                    label: { EmptyView() }
                )
 
            }
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
