//
//  alumnos.swift
//  proyecto
//
//  Created by MacOsX on 12/4/23.
//

import SwiftUI

struct alumnos: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct alumnos_Previews: PreviewProvider {
    static var previews: some View {
        alumnos()
    }
}
