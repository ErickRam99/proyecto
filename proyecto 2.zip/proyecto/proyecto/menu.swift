//
//  menu.swift
//  proyecto
//
//  Created by MacOsX on 12/9/23.
//

import SwiftUI

struct menu: View {
    var body: some View {
        NavigationView{
            List{
                Section(header: Text ("opciones")){
                    NavigationLink(
                        destination: profesores()){
                        Text("Profesores ")
                    }
                    NavigationLink(destination: alumnos()){
                        Text("Alumnos ")
 
                    }

                }
                Section(header: Text ("opciones")){
                    NavigationLink(
                        destination: ListadoAlumnos()){
                        Text("Listado de Alumnos ")
                    }
                }

            }
            .listStyle(GroupedListStyle())
        }
    }
}
struct menu_Previews: PreviewProvider {
    static var previews: some View {
        menu()
    }
}
