//
//  profesores.swift
//  proyecto
//
//  Created by MacOsX on 12/4/23.
//

import SwiftUI

import SwiftUI
 
struct profesores: View {
    @State private var firstName = ""
    @State private var lastName = ""
    @State private var subject = ""
    @State private var email = ""
 
    var body: some View {
        
        
            VStack{
                Image("profe")
                    .resizable()
                    .scaledToFit()
                    .frame(width:150, height:150)
                    .padding(.top,5)
                
            Form {
                Section(header: Text("Información Personal")) {
                    TextField("Nombre", text: $firstName)
                    TextField("Apellido", text: $lastName)
                }
 
                Section(header: Text("Información Académica")) {
                    TextField("Asignatura", text: $subject)
                }
 
                Section(header: Text("Información de Contacto")) {
                    TextField("Correo Electrónico", text: $email)
                }
 
                Section {
                    Button(action: {
                     
                        self.saveProfessor()
                    }) {
                    
                        Text("Guardar")
                      
                        
                    }
                }
            }
            .navigationBarTitle("Formulario de Profesor")
            }
        
    }
 
    func saveProfessor() {
        // Aquí puedes implementar la lógica para guardar los datos del profesor
        // Por ejemplo, podrías enviar los datos a una API o guardarlos localmente.
        // También puedes mostrar una alerta o realizar otras acciones según tus necesidades.
    }
}

struct profesores_Previews: PreviewProvider {
    static var previews: some View {
        profesores()
    }
}
