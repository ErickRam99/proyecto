//
//  alumnos.swift
//  proyecto
//
//  Created by MacOsX on 12/4/23.
//

import SwiftUI

struct alumnos: View {
    @State private var studentName = ""
        @State private var studentAge = ""
        @State private var studentGrade = ""
        var body: some View {
            Image("alumno")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 100, height: 100)
                            .padding(.bottom, 30)
            Form {
                Section(header: Text("Información del Alumno")) {
                    TextField("Nombre", text: $studentName)
                    TextField("Edad", text: $studentAge)
                    TextField("Grado", text: $studentGrade)
                    TextField("Email", text: $studentGrade)
                    TextField("Materia ", text: $studentGrade)
                }
                Section {
                    Button(action: {
                        // Aquí puedes manejar la lógica para guardar la información del alumno
                        self.saveStudentInformation()
                    }) {
                      
   
                        Button("Guardar Información"){
                            
                        }
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .padding()
                        
         
                    }
                }
                
            }
            .navigationBarTitle("Detalle del Alumno")
        }
  
        func saveStudentInformation() {
            // Aquí puedes implementar la lógica para guardar la información del alumno
            // Puedes guardar los datos localmente, en una base de datos, o enviarlos a una API, según tus necesidades.
            // También puedes mostrar una alerta o realizar otras acciones según tus necesidades.
        }
    }

struct alumnos_Previews: PreviewProvider {
    static var previews: some View {
        alumnos()
    }
}
