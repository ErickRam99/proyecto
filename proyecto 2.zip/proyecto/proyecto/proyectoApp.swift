//
//  proyectoApp.swift
//  proyecto
//
//  Created by MacOsX on 12/3/23.
//

import SwiftUI

@main
struct proyectoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
